import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;

public class CustomerGUI extends JFrame {
    private JTable booksTable;
    private DefaultTableModel booksTableModel, basketTableModel;
    private JButton btnAddToBasket, btnSearchByAuthor, btnViewBasket, btnBack;
    private JTextField txtISBN, txtQuantity, txtAuthorSearch;
    private String customerEmail;

    public CustomerGUI(String email) {
        this.customerEmail = email;
        setTitle("AlGasaq Bookstore");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Initialize Table Models
        booksTableModel = new DefaultTableModel(new String[]{"ISBN", "Title", "Author", "Price", "StockNumber", "WarehouseCode"}, 0);
        booksTable = new JTable(booksTableModel);
        JScrollPane booksScrollPane = new JScrollPane(booksTable);

        // Initialize basketTableModel
        basketTableModel = new DefaultTableModel(new String[]{"ISBN", "Title", "Quantity", "Price"}, 0);

        // Control Panel
        JPanel controlPanel = new JPanel();
        txtISBN = new JTextField(10);
        txtQuantity = new JTextField(5);
        txtAuthorSearch = new JTextField(10);
        btnAddToBasket = new JButton("Add to Basket");
        btnSearchByAuthor = new JButton("Search by Author");
        btnViewBasket = new JButton("View Basket");
        btnBack = new JButton("Back");

        btnSearchByAuthor.addActionListener(this::searchByAuthor);
        btnAddToBasket.addActionListener(this::addToBasket);
        btnViewBasket.addActionListener(this::viewBasket);
        btnBack.addActionListener(e -> goBack());

        controlPanel.add(new JLabel("Author:"));
        controlPanel.add(txtAuthorSearch);
        controlPanel.add(btnSearchByAuthor);
        controlPanel.add(new JLabel("ISBN:"));
        controlPanel.add(txtISBN);
        controlPanel.add(new JLabel("Quantity:"));
        controlPanel.add(txtQuantity);
        controlPanel.add(btnAddToBasket);
        controlPanel.add(btnViewBasket);
        controlPanel.add(btnBack);

        add(booksScrollPane, BorderLayout.CENTER);
        add(controlPanel, BorderLayout.SOUTH);

        loadBooks();
        setVisible(true);
    }

    private void loadBooks() {
        loadBooks(null);
    }

    private void loadBooks(String author) {
        String query = "SELECT ISBN, title, Author_Name, price, StockNumber, warehouse_code FROM book";
        if (author != null && !author.isEmpty()) {
            query += " WHERE Author_Name LIKE ?";
        }

        try (Connection conn = Check.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            if (author != null && !author.isEmpty()) {
                pstmt.setString(1, "%" + author + "%");
            }

            ResultSet rs = pstmt.executeQuery();
            booksTableModel.setRowCount(0);  // Clear existing data
            while (rs.next()) {
                booksTableModel.addRow(new Object[]{
                        rs.getInt("ISBN"),
                        rs.getString("title"),
                        rs.getString("Author_Name"),
                        rs.getDouble("price"),
                        rs.getInt("StockNumber"),
                        rs.getInt("warehouse_code")
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading books: " + e.getMessage());
        }
    }

    private void searchByAuthor(ActionEvent event) {
        String author = txtAuthorSearch.getText().trim();
        loadBooks(author);
    }

    private void addToBasket(ActionEvent event) {
        String isbn = txtISBN.getText();
        String quantity = txtQuantity.getText();
        try {
            int qty = Integer.parseInt(quantity);
            if (qty <= 0) {
                JOptionPane.showMessageDialog(this, "Quantity must be greater than 0!");
                return;
            }
            for (int i = 0; i < booksTableModel.getRowCount(); i++) {
                if (booksTableModel.getValueAt(i, 0).toString().equals(isbn)) {
                    String title = booksTableModel.getValueAt(i, 1).toString();
                    double price = Double.parseDouble(booksTableModel.getValueAt(i, 3).toString()) * qty;
                    int stock = (int) booksTableModel.getValueAt(i, 4);
                    if (qty > stock) {
                        JOptionPane.showMessageDialog(this, "Not enough stock available!");
                        return;
                    }
                    basketTableModel.addRow(new Object[]{isbn, title, qty, price});
                    break;
                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid quantity!");
        }
    }
    

    private void viewBasket(ActionEvent event) {
        JFrame basketFrame = new JFrame("Basket");
        basketFrame.setSize(500, 300);
        basketFrame.setLocationRelativeTo(null);
        basketFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JTable basketTable = new JTable(basketTableModel);
        JScrollPane basketScrollPane = new JScrollPane(basketTable);

        JButton btnPurchase = new JButton("Purchase");
        JButton btnClearBasket = new JButton("Clear Basket");

        btnPurchase.addActionListener(e -> purchaseItems(basketTableModel));
        btnClearBasket.addActionListener(e -> clearBasket(basketTableModel));

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(btnPurchase);
        buttonPanel.add(btnClearBasket);

        basketFrame.add(basketScrollPane, BorderLayout.CENTER);
        basketFrame.add(buttonPanel, BorderLayout.SOUTH);
        basketFrame.setVisible(true);
    }

    private void purchaseItems(DefaultTableModel basketTableModel) {
        if (basketTableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No items in the basket to purchase!");
            return;
        }
        try (Connection conn = Check.getConnection()) {
            conn.setAutoCommit(false); // Start transaction
            for (int i = 0; i < basketTableModel.getRowCount(); i++) {
                String isbn = basketTableModel.getValueAt(i, 0).toString();
                int quantity = Integer.parseInt(basketTableModel.getValueAt(i, 2).toString());

                // Update the stock number in the database
                PreparedStatement psUpdate = conn.prepareStatement(
                        "UPDATE book SET StockNumber = StockNumber - ? WHERE ISBN = ? AND StockNumber >= ?");
                psUpdate.setInt(1, quantity);
                psUpdate.setString(2, isbn);
                psUpdate.setInt(3, quantity);
                int affectedRows = psUpdate.executeUpdate();
                if (affectedRows == 0) {
                    throw new SQLException("Book stock not updated. Possibly due to insufficient stock.");
                }
            }
            conn.commit(); // Commit transaction
            JOptionPane.showMessageDialog(this, "Purchase successful!");
            basketTableModel.setRowCount(0); // Clear the basket
            loadBooks(); // Reload books to reflect the new stock numbers
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error during purchase: " + e.getMessage());
        }
    }

    private void clearBasket(DefaultTableModel basketTableModel) {
        basketTableModel.setRowCount(0);
    }

    private void goBack() {
        dispose(); // Close the current window
        Main.displayRoleSelection(); // Display the role selection menu again
    }

    public static String promptCustomerData() {
        JPanel panel = new JPanel(new GridLayout(4, 2));
        JTextField txtName = new JTextField();
        JTextField txtAddress = new JTextField();
        JTextField txtEmail = new JTextField();
        JTextField txtPhone = new JTextField();
        panel.add(new JLabel("Name:"));
        panel.add(txtName);
        panel.add(new JLabel("Address:"));
        panel.add(txtAddress);
        panel.add(new JLabel("Email:"));
        panel.add(txtEmail);
        panel.add(new JLabel("Phone:"));
        panel.add(txtPhone);

        int result = JOptionPane.showConfirmDialog(null, panel, "Enter Customer Information",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            String name = txtName.getText().trim();
            String address = txtAddress.getText().trim();
            String email = txtEmail.getText().trim();
            String phone = txtPhone.getText().trim();

            if (name.isEmpty() || address.isEmpty() || email.isEmpty() || phone.isEmpty()) {
                JOptionPane.showMessageDialog(null, "All fields must be filled out!", "Error", JOptionPane.ERROR_MESSAGE);
                return null;
            }

            try (Connection conn = Check.getConnection()) {
                // Check if email already exists
                String checkEmailSql = "SELECT * FROM `customer` WHERE `email` = ?";
                PreparedStatement psCheckEmail = conn.prepareStatement(checkEmailSql);
                psCheckEmail.setString(1, email);
                ResultSet rs = psCheckEmail.executeQuery();

                if (rs.next()) {
                    JOptionPane.showMessageDialog(null, "Welcome back to our Bookstore!", "", JOptionPane.INFORMATION_MESSAGE);
                    return email;
                }

                // Determine the next available BasketID
                String getMaxBasketIdSql = "SELECT MAX(BasketID) AS maxBasketId FROM `shopping-basket`";
                Statement stmt = conn.createStatement();
                ResultSet rsMaxBasketId = stmt.executeQuery(getMaxBasketIdSql);
                int newBasketId = 1; // Default value

                if (rsMaxBasketId.next()) {
                    newBasketId = rsMaxBasketId.getInt("maxBasketId") + 1;
                }

                // Insert new basket
                String insertBasketSql = "INSERT INTO `shopping-basket` (BasketID) VALUES (?)";
                PreparedStatement psInsertBasket = conn.prepareStatement(insertBasketSql);
                psInsertBasket.setInt(1, newBasketId);
                psInsertBasket.executeUpdate();

                // Insert new customer
                String insertCustomerSql = "INSERT INTO `customer` (`email`, `name`, `address`, `phone`, `shopping-basket_BasketID`) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement psInsertCustomer = conn.prepareStatement(insertCustomerSql);
                psInsertCustomer.setString(1, email);
                psInsertCustomer.setString(2, name);
                psInsertCustomer.setString(3, address);
                psInsertCustomer.setString(4, phone);
                psInsertCustomer.setInt(5, newBasketId);
                int affectedRows = psInsertCustomer.executeUpdate();

                if (affectedRows > 0) {
                    JOptionPane.showMessageDialog(null, "Customer data saved successfully.");
                    return email;
                } else {
                    throw new SQLException("Inserting customer failed.");
                }
            } catch (SQLException | ClassNotFoundException e) {
                JOptionPane.showMessageDialog(null, "Error saving customer data: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
                return null;
            }
        }
        return null;
    }
}

 class AdminGUI extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField[] inputFields;
    private JPanel inputPanel;
    private JComboBox<String> publisherComboBox;
    private JComboBox<String> warehouseComboBox;
    private JComboBox<String> authorComboBox;
    private JComboBox<String> customerComboBox;
    private JButton btnBack;

    public AdminGUI() throws SQLException, ClassNotFoundException {
        setTitle("Admin Panel");
        setSize(800, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Initialize Table Model with example columns
        tableModel = new DefaultTableModel(new String[]{"ID", "Name", "Details"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Control Panel for admin options
        JPanel controlPanel = new JPanel();
        JComboBox<String> tableSelector = new JComboBox<>(new String[]{"Author", "Publisher", "Book", "Warehouse", "Customer", "Shopping-Basket"});
        JButton btnLoadTable = new JButton("Load Table");
        JButton btnInsert = new JButton("Insert");
        JButton btnUpdate = new JButton("Update");
        JButton btnDelete = new JButton("Delete");
        btnBack = new JButton("Back");

        btnLoadTable.addActionListener(e -> {
            try {
                loadTableData(tableSelector.getSelectedItem().toString());
            } catch (SQLException | ClassNotFoundException ex) {
                JOptionPane.showMessageDialog(this, "Error loading table data: " + ex.getMessage());
            }
        });
        btnInsert.addActionListener(e -> {
            try {
                insertData(tableSelector.getSelectedItem().toString());
            } catch (SQLException | ClassNotFoundException ex) {
                JOptionPane.showMessageDialog(this, "Error inserting data: " + ex.getMessage());
            }
        });
        btnUpdate.addActionListener(e -> {
            try {
                updateData(tableSelector.getSelectedItem().toString());
            } catch (SQLException | ClassNotFoundException ex) {
                JOptionPane.showMessageDialog(this, "Error updating data: " + ex.getMessage());
            }
        });
        btnDelete.addActionListener(e -> {
            try {
                deleteData(tableSelector.getSelectedItem().toString());
            } catch (SQLException | ClassNotFoundException ex) {
                JOptionPane.showMessageDialog(this, "Error deleting data: " + ex.getMessage());
            }
        });
        btnBack.addActionListener(e -> goBack());

        controlPanel.add(new JLabel("Select Table:"));
        controlPanel.add(tableSelector);
        controlPanel.add(btnLoadTable);
        controlPanel.add(btnInsert);
        controlPanel.add(btnUpdate);
        controlPanel.add(btnDelete);
        controlPanel.add(btnBack);

        add(scrollPane, BorderLayout.CENTER);
        add(controlPanel, BorderLayout.SOUTH);

        setVisible(true);

        // Table row selection listener
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                int selectedRow = table.getSelectedRow();
                for (int i = 0; i < inputFields.length; i++) {
                    if (inputFields[i] != null) {
                        inputFields[i].setText(tableModel.getValueAt(selectedRow, i).toString());
                    }
                }
            }
        });
    }

    private void loadTableData(String tableName) throws SQLException, ClassNotFoundException {
        try (Connection conn = Check.getConnection();
             Statement stmt = conn.createStatement()) {
            String query = "SELECT * FROM `" + tableName + "`";
            ResultSet rs = stmt.executeQuery(query);
            tableModel.setRowCount(0); // Clear existing data

            // Dynamically set table columns based on ResultSet metadata
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            String[] columnNames = new String[columnCount];
            for (int i = 0; i < columnCount; i++) {
                columnNames[i] = metaData.getColumnName(i + 1);
            }
            tableModel.setColumnIdentifiers(columnNames);

            while (rs.next()) {
                Object[] rowData = new Object[columnCount];
                for (int i = 0; i < columnCount; i++) {
                    String columnName = metaData.getColumnName(i + 1);
                    if (columnName.equalsIgnoreCase("year")) {
                        // Convert 'year' from yyyy-mm-dd to yyyy format
                        rowData[i] = rs.getString(columnName).substring(0, 4);
                    } else {
                        rowData[i] = rs.getObject(i + 1);
                    }
                }
                tableModel.addRow(rowData);
            }

            // Create input fields for the columns
            createInputFields(columnNames, tableName);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading table data: " + e.getMessage());
        }
    }

    private void createInputFields(String[] columnNames, String tableName) {
        if (inputPanel != null) {
            remove(inputPanel);
        }
        inputPanel = new JPanel(new GridLayout(columnNames.length, 2));
        inputFields = new JTextField[columnNames.length];

        for (int i = 0; i < columnNames.length; i++) {
            inputPanel.add(new JLabel(columnNames[i] + ":"));
            if (columnNames[i].equalsIgnoreCase("Publisher_Name")) {
                publisherComboBox = new JComboBox<>(getOptionsFromDatabase("Publisher", "Name"));
                inputPanel.add(publisherComboBox);
                inputFields[i] = null; // Mark this field as a combo box
            } else if (columnNames[i].equalsIgnoreCase("Warehouse_Code")) {
                warehouseComboBox = new JComboBox<>(getOptionsFromDatabase("Warehouse", "Code"));
                inputPanel.add(warehouseComboBox);
                inputFields[i] = null; // Mark this field as a combo box
            } else if (columnNames[i].equalsIgnoreCase("Author_Name")) {
                authorComboBox = new JComboBox<>(getOptionsFromDatabase("Author", "Name"));
                inputPanel.add(authorComboBox);
                inputFields[i] = null; // Mark this field as a combo box
            } else if (columnNames[i].equalsIgnoreCase("shopping-basket_BasketID")) {
                customerComboBox = new JComboBox<>(getOptionsFromDatabase("shopping-basket", "BasketID"));
                inputPanel.add(customerComboBox);
                inputFields[i] = null; // Mark this field as a combo box
            } else {
                inputFields[i] = new JTextField();
                inputFields[i].setName(columnNames[i]);
                if (columnNames[i].equalsIgnoreCase("year")) {
                    inputFields[i].setInputVerifier(new InputVerifier() {
                        @Override
                        public boolean verify(JComponent input) {
                            JTextField textField = (JTextField) input;
                            return isValidYear(textField.getText().trim());
                        }
                    });
                }
                inputPanel.add(inputFields[i]);
            }
        }
        add(inputPanel, BorderLayout.NORTH);
        revalidate();
        repaint();
    }

    private String[] getOptionsFromDatabase(String tableName, String columnName) {
        try (Connection conn = Check.getConnection();
             Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY)) {
            String query = "SELECT " + columnName + " FROM `" + tableName + "`";
            ResultSet rs = stmt.executeQuery(query);
            rs.last();
            int rowCount = rs.getRow();
            rs.beforeFirst();
            String[] options = new String[rowCount];
            int i = 0;
            while (rs.next()) {
                options[i++] = rs.getString(columnName);
            }
            return options;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading options: " + e.getMessage());
            return new String[]{};
        }
    }

    private boolean isValidYear(String year) {
        return year.matches("\\d{4}");
    }

    private boolean isValidISBN(String isbn) {
        try {
            int isbnValue = Integer.parseInt(isbn);
            return isbnValue > 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private boolean isValidPrice(String price) {
        try {
            double priceValue = Double.parseDouble(price);
            return priceValue > 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private boolean isValidStockNumber(String stockNumber) {
        try {
            int stockValue = Integer.parseInt(stockNumber);
            return stockValue > 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private boolean isValidPhone(String phone) {
        return phone.matches("\\d{10}"); // Assuming valid phone numbers are 10 digits long
    }

    private void insertData(String tableName) throws SQLException, ClassNotFoundException {
        try (Connection conn = Check.getConnection()) {
            StringBuilder query = new StringBuilder("INSERT INTO `" + tableName + "` (");
            StringBuilder values = new StringBuilder("VALUES (");
            boolean isBookTable = tableName.equalsIgnoreCase("Book");
            boolean isCustomerTable = tableName.equalsIgnoreCase("Customer");
            boolean isPublisherTable = tableName.equalsIgnoreCase("Publisher");
            boolean isWarehouseTable = tableName.equalsIgnoreCase("Warehouse");

            for (int i = 0; i < inputFields.length; i++) {
                if (inputFields[i] != null) {
                    String columnName = inputFields[i].getName();
                    query.append("`").append(columnName).append("`").append(i < inputFields.length - 1 ? ", " : ")");
                    values.append("?").append(i < inputFields.length - 1 ? ", " : ")");

                    if (isBookTable) {
                        if (columnName.equalsIgnoreCase("ISBN")) {
                            String isbnValue = inputFields[i].getText().trim();
                            if (!isValidISBN(isbnValue)) {
                                throw new IllegalArgumentException("Invalid ISBN. It must be a positive integer.");
                            }
                        } else if (columnName.equalsIgnoreCase("price")) {
                            String priceValue = inputFields[i].getText().trim();
                            if (!isValidPrice(priceValue)) {
                                throw new IllegalArgumentException("Invalid price. It must be a positive number.");
                            }
                        } else if (columnName.equalsIgnoreCase("StockNumber")) {
                            String stockValue = inputFields[i].getText().trim();
                            if (!isValidStockNumber(stockValue)) {
                                throw new IllegalArgumentException("Invalid stock number. It must be a positive integer.");
                            }
                        }
                    } else if (columnName.equalsIgnoreCase("year")) {
                        String yearValue = inputFields[i].getText().trim();
                        if (!isValidYear(yearValue)) {
                            throw new IllegalArgumentException("Invalid year format. Use yyyy.");
                        }
                    } else if (isCustomerTable || isPublisherTable || isWarehouseTable) {
                        if (columnName.equalsIgnoreCase("phone")) {
                            String phoneValue = inputFields[i].getText().trim();
                            if (!isValidPhone(phoneValue)) {
                                throw new IllegalArgumentException("Invalid phone number. It must be 10 digits.");
                            }
                        }
                    }
                } else if (publisherComboBox != null && i == findColumnIndex("Publisher_Name")) {
                    query.append("`Publisher_Name`").append(i < inputFields.length - 1 ? ", " : ")");
                    values.append("?").append(i < inputFields.length - 1 ? ", " : ")");
                } else if (warehouseComboBox != null && i == findColumnIndex("Warehouse_Code")) {
                    query.append("`Warehouse_Code`").append(i < inputFields.length - 1 ? ", " : ")");
                    values.append("?").append(i < inputFields.length - 1 ? ", " : ")");
                } else if (authorComboBox != null && i == findColumnIndex("Author_Name")) {
                    query.append("`Author_Name`").append(i < inputFields.length - 1 ? ", " : ")");
                    values.append("?").append(i < inputFields.length - 1 ? ", " : ")");
                } else if (customerComboBox != null && i == findColumnIndex("shopping-basket_BasketID")) {
                    query.append("`shopping-basket_BasketID`").append(i < inputFields.length - 1 ? ", " : ")");
                    values.append("?").append(i < inputFields.length - 1 ? ", " : ")");
                }
            }
            query.append(" ").append(values);

            PreparedStatement psInsert = conn.prepareStatement(query.toString());
            for (int i = 0; i < inputFields.length; i++) {
                if (inputFields[i] != null) {
                    String value = inputFields[i].getText().trim();
                    psInsert.setObject(i + 1, value);
                } else if (publisherComboBox != null && i == findColumnIndex("Publisher_Name")) {
                    psInsert.setObject(i + 1, publisherComboBox.getSelectedItem());
                } else if (warehouseComboBox != null && i == findColumnIndex("Warehouse_Code")) {
                    psInsert.setObject(i + 1, warehouseComboBox.getSelectedItem());
                } else if (authorComboBox != null && i == findColumnIndex("Author_Name")) {
                    psInsert.setObject(i + 1, authorComboBox.getSelectedItem());
                } else if (customerComboBox != null && i == findColumnIndex("shopping-basket_BasketID")) {
                    psInsert.setObject(i + 1, customerComboBox.getSelectedItem());
                }
            }
            int affectedRows = psInsert.executeUpdate();
            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(this, "Data inserted successfully.");
                loadTableData(tableName); // Reload table data
            } else {
                throw new SQLException("Inserting data failed.");
            }
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Validation Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error inserting data: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private int findColumnIndex(String columnName) {
        for (int i = 0; i < tableModel.getColumnCount(); i++) {
            if (tableModel.getColumnName(i).equalsIgnoreCase(columnName)) {
                return i;
            }
        }
        return -1;
    }

    private void updateData(String tableName) throws SQLException, ClassNotFoundException {
        Connection conn = null;
        try {
            conn = Check.getConnection();
            conn.setAutoCommit(false); // Start transaction

            String primaryKeyField = inputFields[0].getName();
            String primaryKeyOldValue = table.getValueAt(table.getSelectedRow(), 0).toString();
            String primaryKeyNewValue = inputFields[0].getText().trim();

            // Update all fields except the primary key
            StringBuilder query = new StringBuilder("UPDATE `" + tableName + "` SET ");
            for (int i = 1; i < inputFields.length; i++) { // Skip the first field (assumed to be ID)
                if (inputFields[i] != null) {
                    query.append("`").append(inputFields[i].getName()).append("` = ?");
                    if (i < inputFields.length - 1) {
                        query.append(", ");
                    }
                } else if (publisherComboBox != null && i == findColumnIndex("Publisher_Name")) {
                    query.append("`Publisher_Name` = ?");
                    if (i < inputFields.length - 1) {
                        query.append(", ");
                    }
                } else if (warehouseComboBox != null && i == findColumnIndex("Warehouse_Code")) {
                    query.append("`Warehouse_Code` = ?");
                    if (i < inputFields.length - 1) {
                        query.append(", ");
                    }
                } else if (authorComboBox != null && i == findColumnIndex("Author_Name")) {
                    query.append("`Author_Name` = ?");
                    if (i < inputFields.length - 1) {
                        query.append(", ");
                    }
                } else if (customerComboBox != null && i == findColumnIndex("shopping-basket_BasketID")) {
                    query.append("`shopping-basket_BasketID` = ?");
                    if (i < inputFields.length - 1) {
                        query.append(", ");
                    }
                }
            }
            query.append(" WHERE ").append("`").append(primaryKeyField).append("` = ?");

            try (PreparedStatement psUpdate = conn.prepareStatement(query.toString())) {
                int paramIndex = 1;
                for (int i = 1; i < inputFields.length; i++) {
                    if (inputFields[i] != null) {
                        String columnName = inputFields[i].getName();
                        String value = inputFields[i].getText().trim();
                        if (columnName.equalsIgnoreCase("year")) {
                            if (!isValidYear(value)) {
                                throw new IllegalArgumentException("Invalid year format. Use yyyy.");
                            }
                        }
                        psUpdate.setObject(paramIndex++, value);
                    } else if (publisherComboBox != null && i == findColumnIndex("Publisher_Name")) {
                        psUpdate.setObject(paramIndex++, publisherComboBox.getSelectedItem());
                    } else if (warehouseComboBox != null && i == findColumnIndex("Warehouse_Code")) {
                        psUpdate.setObject(paramIndex++, warehouseComboBox.getSelectedItem());
                    } else if (authorComboBox != null && i == findColumnIndex("Author_Name")) {
                        psUpdate.setObject(paramIndex++, authorComboBox.getSelectedItem());
                    } else if (customerComboBox != null && i == findColumnIndex("shopping-basket_BasketID")) {
                        psUpdate.setObject(paramIndex++, customerComboBox.getSelectedItem());
                    }
                }
                psUpdate.setObject(paramIndex, primaryKeyOldValue);
                psUpdate.executeUpdate();
            }

            // If the primary key value has changed, update it separately
            if (!primaryKeyOldValue.equals(primaryKeyNewValue)) {
                String updatePrimaryKeyQuery = "UPDATE `" + tableName + "` SET `" + primaryKeyField + "` = ? WHERE `" + primaryKeyField + "` = ?";
                try (PreparedStatement psUpdatePrimaryKey = conn.prepareStatement(updatePrimaryKeyQuery)) {
                    psUpdatePrimaryKey.setObject(1, primaryKeyNewValue);
                    psUpdatePrimaryKey.setObject(2, primaryKeyOldValue);
                    psUpdatePrimaryKey.executeUpdate();
                }
            }

            conn.commit(); // Commit transaction
            JOptionPane.showMessageDialog(this, "Data updated successfully.");
            loadTableData(tableName); // Reload table data
        } catch (SQLException e) {
            if (conn != null) {
                conn.rollback(); // Rollback transaction in case of error
            }
            JOptionPane.showMessageDialog(this, "Error updating data: " + e.getMessage());
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }

    private void deleteData(String tableName) throws SQLException, ClassNotFoundException {
        try (Connection conn = Check.getConnection()) {
            String primaryKeyField = inputFields[0].getName();
            String primaryKeyValue = inputFields[0].getText().trim();

            if (tableName.equalsIgnoreCase("Author")) {
                // Delete books associated with the author
                String deleteBooksQuery = "DELETE FROM book WHERE Author_Name = ?";
                try (PreparedStatement psDeleteBooks = conn.prepareStatement(deleteBooksQuery)) {
                    psDeleteBooks.setString(1, primaryKeyValue);
                    psDeleteBooks.executeUpdate();
                }
            } else if (tableName.equalsIgnoreCase("Publisher")) {
                // Delete books associated with the publisher
                String deleteBooksQuery = "DELETE FROM book WHERE Publisher_Name = ?";
                try (PreparedStatement psDeleteBooks = conn.prepareStatement(deleteBooksQuery)) {
                    psDeleteBooks.setString(1, primaryKeyValue);
                    psDeleteBooks.executeUpdate();
                }
            } else if (tableName.equalsIgnoreCase("Warehouse")) {
                // Check for other warehouses
                String checkOtherWarehousesQuery = "SELECT code FROM warehouse WHERE code != ?";
                try (PreparedStatement psCheckWarehouses = conn.prepareStatement(checkOtherWarehousesQuery)) {
                    psCheckWarehouses.setString(1, primaryKeyValue);
                    ResultSet rs = psCheckWarehouses.executeQuery();

                    if (rs.next()) {
                        // Other warehouses exist, reassign books to the first found warehouse
                        String newWarehouseCode = rs.getString("code");
                        String updateBooksQuery = "UPDATE book SET Warehouse_Code = ? WHERE Warehouse_Code = ?";
                        try (PreparedStatement psUpdateBooks = conn.prepareStatement(updateBooksQuery)) {
                            psUpdateBooks.setString(1, newWarehouseCode);
                            psUpdateBooks.setString(2, primaryKeyValue);
                            psUpdateBooks.executeUpdate();
                        }
                    } else {
                        // No other warehouses exist, delete books associated with this warehouse
                        String deleteBooksQuery = "DELETE FROM book WHERE Warehouse_Code = ?";
                        try (PreparedStatement psDeleteBooks = conn.prepareStatement(deleteBooksQuery)) {
                            psDeleteBooks.setString(1, primaryKeyValue);
                            psDeleteBooks.executeUpdate();
                        }
                    }
                }
            } else if (tableName.equalsIgnoreCase("shopping_basket")) {
                // Delete customers associated with this BasketID
                String deleteCustomersQuery = "DELETE FROM customer WHERE shopping_basket_BasketID = ?";
                try (PreparedStatement psDeleteCustomers = conn.prepareStatement(deleteCustomersQuery)) {
                    psDeleteCustomers.setString(1, primaryKeyValue);
                    psDeleteCustomers.executeUpdate();
                }
            }

            // Now delete the author, publisher, warehouse, or shopping basket
            String query = "DELETE FROM `" + tableName + "` WHERE " + primaryKeyField + " = ?";
            try (PreparedStatement psDelete = conn.prepareStatement(query)) {
                psDelete.setString(1, primaryKeyValue);
                int affectedRows = psDelete.executeUpdate();
                if (affectedRows > 0) {
                    JOptionPane.showMessageDialog(this, "Data deleted successfully.");
                    loadTableData(tableName); // Reload table data
                } else {
                    throw new SQLException("Deleting data failed.");
                }
            }
        }
    }

    private void goBack() {
        dispose(); // Close the current window
        Main.displayRoleSelection(); // Display the role selection menu again
    }
}

class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(Main::displayRoleSelection);
    }

    public static void displayRoleSelection() {
        String[] options = {"Customer", "Admin"};
        int choice = JOptionPane.showOptionDialog(null, "Choose your role", "Role Selection",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
        if (choice == 0) {
            String email = CustomerGUI.promptCustomerData();
            if (email != null) {
                new CustomerGUI(email);
            }
        } else if (choice == 1) {
            try {
                new AdminGUI();
            } catch (SQLException | ClassNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Error initializing Admin GUI: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}

